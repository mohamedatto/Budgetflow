# Student Finance Dashboard

A desktop budgeting app built by Mohamed Atto with Java 17, JavaFX, SQLite, and JDBC. Add income and expenses, inspect monthly spending, and set a monthly expense budget. No paid database, bank connection, API key, or account is required.

## Run on your computer

1. Install JDK 17 and Apache Maven. Verify `java -version` and `mvn -version` in Terminal.
2. Open Terminal in this folder (the folder containing `pom.xml`).
3. Run `mvn clean test`.
4. Run `mvn javafx:run`.

Maven downloads open-source dependencies on the first run, so internet is needed initially. The app then stores its data locally. Use a full desktop JDK installation; JavaFX requires a graphical desktop.

## First demo

Click **Load sample data**. Five clearly labeled sample transactions and a $1,000 expense budget appear for the selected month. Sample income is $1,200; expenses are $835.45; net is $364.55; remaining budget is $164.55. Samples load only into an empty month. Change the month with `YYYY-MM` and click **View month**. Add a transaction, search the table, save a budget, then restart to demonstrate persistence. Select a row and click **Delete selected** to remove it after confirmation.

## Features

- Add dated income and expenses across six categories.
- Filter by month; search description, category, or type.
- View full-month income, expense, net, and budget totals.
- Visualize expense categories with a pie chart.
- Save a budget separately for each month.
- Persist records across restarts using SQLite.
- Validate amounts and confirm deletion.

Search filters the table only; summary cards and the pie chart continue to represent the full month. Net is selected-month income minus expenses, not an all-time bank balance. All amounts are USD. A negative remaining budget means spending exceeded the budget.

## Architecture

`FinanceApp.java`: JavaFX interface and dashboard aggregation.
`FinanceStore.java`: schema, prepared SQL statements, sample-data transaction, and persistence.
`Transaction.java`: immutable data record and amount validation.
`style.css`: interface appearance.
`FinanceStoreTest.java`: amount validation, persistence, month boundaries, budget updates, deletion, and repeat-safe demo loading.

Amounts use integer cents rather than floating point. Date queries use an inclusive first-day boundary and an exclusive next-month boundary, backed by a date index. User input is passed through prepared statements. Resources close with try-with-resources. The desktop app deliberately keeps database calls synchronous for a small local dataset; background tasks would be a useful extension for larger imports.

## Data location

The database lives in `.student-finance/finance.db` inside your user home directory, separate from the repository. Keep personal financial data out of GitHub. Closing the app and backing up that file preserves your data. To reset everything, close the app and rename or remove that database; this permanently clears records if you delete it without a backup.

## GitHub

Create an empty repository called `student-finance-dashboard`, then from this folder:

```bash
git init
git add .
git commit -m "Build student finance dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/student-finance-dashboard.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. Take a screenshot after opening sample data and add it to the README. The included GitHub Actions workflow runs the tests on pushes and pull requests. This is a Java desktop app; GitHub Pages cannot run it. Interviewers can clone and run it, or watch a short screen recording.

## Honest resume bullet

Built a JavaFX finance dashboard with SQLite and JDBC to track income and expenses, manage monthly budgets, and visualize spending by category.

Do not claim 500 real records, a measured query speedup, or user results until you have generated or collected the data and measured the results. Future work: transaction editing, CSV import/export, per-category budgets, and a packaged installer. These features are not implemented in version 1.

## Interview walkthrough

Explain the transaction model, why cents prevent rounding errors, how a prepared statement stores a transaction, how month boundaries filter data, and how the dashboard calculates totals. Show the persistence test and discuss one limitation and how you would improve it.

## Layout update

The dashboard now has a centered maximum-width layout, a compact scrollable transaction table, larger text and chart, and labeled budget usage. Overspending turns the budget balance and progress bar red. The entire dashboard scrolls vertically when needed.

To update an existing installation, close the app, unzip this project into a new folder, and run it from that folder. Your existing database is outside the project folder, so the updated app uses the same saved transactions.
