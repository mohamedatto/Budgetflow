# Validation

All main and test Java sources compiled successfully for Java 17 using Eclipse ECJ 3.38.0. JUnit Platform 1.11.0 ran all three tests successfully against SQLite JDBC 3.46.1.0.

Tests cover amount precision and invalid input, persistence across connections, month boundaries, descriptions containing apostrophes, budget replacement, deletion, and repeat-safe sample loading with expected totals.

The standard Maven build could not complete here because Maven dependency resolution failed in this environment; dependencies were downloaded separately for compilation and the JUnit run. The JavaFX desktop window has not been launched or visually checked here because a graphical display is unavailable. Run `mvn clean test` followed by `mvn javafx:run` on a desktop with JDK 17 and Maven to complete that verification.
