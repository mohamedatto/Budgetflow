package com.mohamedatto.finance;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.time.*;
import static org.junit.jupiter.api.Assertions.*;
class FinanceStoreTest {
 @TempDir Path temp;
 @Test void moneyValidation(){assertEquals(1234,Transaction.parseCents("12.34"));assertThrows(IllegalArgumentException.class,()->Transaction.parseCents("12.345"));assertThrows(IllegalArgumentException.class,()->Transaction.parseCents("0"));assertThrows(IllegalArgumentException.class,()->Transaction.parseCents("-3"));assertThrows(IllegalArgumentException.class,()->Transaction.parseCents("NaN"));}
 @Test void persistsFiltersAndDeletes() throws Exception {
  String url="jdbc:sqlite:"+temp.resolve("test.db");YearMonth m=YearMonth.of(2026,10);
  try(FinanceStore s=new FinanceStore(url)){s.add(new Transaction(0,m.atDay(1),"O'Brien grocery","Food","Expense",1099));s.add(new Transaction(0,m.plusMonths(1).atDay(1),"Next month","Other","Income",5000));s.budget(m,20000);s.budget(m,25000);}
  try(FinanceStore s=new FinanceStore(url)){assertEquals(25000,s.budget(m));assertEquals(1,s.list(m).size());Transaction t=s.list(m).get(0);assertEquals("O'Brien grocery",t.description());assertEquals(1099,t.cents());s.delete(t.id());assertTrue(s.list(m).isEmpty());assertEquals(1,s.list(m.plusMonths(1)).size());}
 }
 @Test void demoIsRepeatSafe() throws Exception {try(FinanceStore s=new FinanceStore("jdbc:sqlite::memory:")){YearMonth m=YearMonth.of(2026,10);assertTrue(s.seed(m));assertFalse(s.seed(m));assertEquals(5,s.list(m).size());long out=s.list(m).stream().filter(t->t.type().equals("Expense")).mapToLong(Transaction::cents).sum();assertEquals(83545,out);assertEquals(100000,s.budget(m));}}
}
