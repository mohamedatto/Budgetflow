package com.mohamedatto.finance;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Money is stored as integer cents, avoiding floating point rounding. */
public record Transaction(long id, LocalDate date, String description, String category, String type, long cents) {
    public static final String[] CATEGORIES = {"Food", "Housing", "Transport", "School", "Entertainment", "Other"};
    public Transaction {
        if (date == null || description == null || description.isBlank() || category == null || category.isBlank())
            throw new IllegalArgumentException("Enter a date, description, and category.");
        if (!type.equals("Income") && !type.equals("Expense")) throw new IllegalArgumentException("Choose Income or Expense.");
        if (cents <= 0) throw new IllegalArgumentException("Amount must be greater than zero.");
    }
    public static long parseCents(String text) {
        try {
            long result = new BigDecimal(text.trim()).movePointRight(2).longValueExact();
            if (result <= 0 || result > 100_000_000L) throw new ArithmeticException();
            return result;
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("Enter a positive amount up to 1,000,000 with at most two decimal places.");
        }
    }
    public static String money(long cents) { return "$" + BigDecimal.valueOf(cents, 2).toPlainString(); }
}
