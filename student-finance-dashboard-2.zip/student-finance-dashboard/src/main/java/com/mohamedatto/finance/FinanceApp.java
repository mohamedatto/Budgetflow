package com.mohamedatto.finance;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.function.Function;

public class FinanceApp extends Application {
    private FinanceStore store;
    private final TextField month = new TextField(YearMonth.now().toString());
    private final TextField search = new TextField();
    private final TableView<Transaction> table = new TableView<>();
    private final Label income = new Label(), expenses = new Label(), balance = new Label(), remaining = new Label(), status = new Label();
    private final PieChart chart = new PieChart();
    private final Label budgetUsage = new Label();
    private final ProgressBar progress = new ProgressBar(0);
    private List<Transaction> rows = List.of();
    private interface Action { void run() throws Exception; }
    private void safely(Action action) {try {action.run();} catch(Exception e){new Alert(Alert.AlertType.ERROR,e.getMessage()).showAndWait();}}
    private YearMonth selectedMonth(){try{return YearMonth.parse(month.getText().trim());}catch(Exception e){throw new IllegalArgumentException("Enter the month as YYYY-MM, such as 2026-10.");}}
    private Button button(String text, Action action){Button b=new Button(text);b.setOnAction(e->safely(action));return b;}
    @Override public void start(Stage stage) throws Exception {
        Path folder=Path.of(System.getProperty("user.home"),".student-finance"); Files.createDirectories(folder);
        store=new FinanceStore("jdbc:sqlite:"+folder.resolve("finance.db"));
        Label title=new Label("Student Finance");title.getStyleClass().add("title");
        Label subtitle=new Label("Your money, one clear picture.  •  Built by Mohamed Atto");subtitle.getStyleClass().add("muted");
        month.setPrefWidth(110); search.setPromptText("Search this month’s transactions");search.setPrefWidth(290);
        search.textProperty().addListener((o,a,b)->filter());
        FlowPane controls=new FlowPane(10,10,new Label("Month"),month,button("View month",this::refresh),search,button("Load sample data",()->{boolean loaded=store.seed(selectedMonth());refresh();status.setText(loaded?"Sample data added. All sample entries are clearly labeled.":"Sample data only loads into an empty month.");}));
        HBox cards=new HBox(14,card("INCOME",income),card("EXPENSES",expenses),card("NET THIS MONTH",balance),card("BUDGET REMAINING",remaining));
        TableColumn<Transaction,String> date=column("Date",t->t.date().toString());
        TableColumn<Transaction,String> desc=column("Description",Transaction::description);desc.setPrefWidth(280);
        table.getColumns().addAll(List.of(date,desc,column("Category",Transaction::category),column("Type",Transaction::type),column("Amount",t->Transaction.money(t.cents()))));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);table.setPlaceholder(new Label("No transactions. Add one below or load sample data."));
        chart.setTitle("Spending by category");chart.setLabelsVisible(false);chart.setAnimated(false);chart.setPrefSize(420,300);chart.setMinHeight(280);
        VBox chartBox=new VBox(12,chart,budgetUsage,progress);chartBox.getStyleClass().add("panel");chartBox.setPrefWidth(460);chartBox.setMinWidth(400);progress.setMaxWidth(Double.MAX_VALUE);budgetUsage.setWrapText(true);
        table.setPrefHeight(360);table.setMinHeight(360);table.setMaxHeight(360);
        HBox middle=new HBox(16,table,chartBox);HBox.setHgrow(table,Priority.ALWAYS);
        DatePicker dateInput=new DatePicker(LocalDate.now());dateInput.setPrefWidth(160);
        TextField description=new TextField();description.setPromptText("Description");description.setPrefWidth(230);
        ComboBox<String> category=new ComboBox<>(FXCollections.observableArrayList(Transaction.CATEGORIES));category.setValue("Food");
        ComboBox<String> type=new ComboBox<>(FXCollections.observableArrayList("Expense","Income"));type.setValue("Expense");
        TextField amount=new TextField();amount.setPromptText("Amount ($)");amount.setPrefWidth(120);
        Button add=button("Add transaction",()->{Transaction t=new Transaction(0,dateInput.getValue(),description.getText(),category.getValue(),type.getValue(),Transaction.parseCents(amount.getText()));store.add(t);month.setText(YearMonth.from(t.date()).toString());description.clear();amount.clear();refresh();status.setText("Transaction saved.");});add.getStyleClass().add("primary");
        FlowPane entry=new FlowPane(10,10,dateInput,description,category,type,amount,add);
        TextField budget=new TextField();budget.setPromptText("Monthly budget ($)");budget.setPrefWidth(170);
        FlowPane actions=new FlowPane(10,10,budget,button("Save budget",()->{store.budget(selectedMonth(),Transaction.parseCents(budget.getText()));refresh();status.setText("Budget saved for "+selectedMonth()+".");}),button("Delete selected",()->{Transaction t=table.getSelectionModel().getSelectedItem();if(t==null)throw new IllegalArgumentException("Select a transaction first.");Alert a=new Alert(Alert.AlertType.CONFIRMATION,"Delete this transaction?",ButtonType.CANCEL,ButtonType.OK);if(a.showAndWait().orElse(ButtonType.CANCEL)==ButtonType.OK){store.delete(t.id());refresh();}}));
        VBox root=new VBox(16,title,subtitle,controls,cards,middle,new Label("ADD A TRANSACTION"),entry,actions,status);root.setPadding(new Insets(28));
        root.setMaxWidth(1250);
        StackPane centered=new StackPane(root);centered.setAlignment(javafx.geometry.Pos.TOP_CENTER);
        ScrollPane scroll=new ScrollPane(centered);scroll.setFitToWidth(true);scroll.setPannable(false);
        Scene scene=new Scene(scroll,1250,900);scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/style.css")).toExternalForm());
        stage.setTitle("Student Finance | Mohamed Atto");stage.setScene(scene);stage.setMinWidth(1000);stage.setMinHeight(700);refresh();stage.show();
    }
    private VBox card(String caption,Label value){Label label=new Label(caption);label.getStyleClass().add("muted");value.getStyleClass().add("metric");VBox v=new VBox(8,label,value);v.getStyleClass().add("panel");HBox.setHgrow(v,Priority.ALWAYS);v.setMaxWidth(Double.MAX_VALUE);return v;}
    private TableColumn<Transaction,String> column(String label,Function<Transaction,String> fn){TableColumn<Transaction,String> c=new TableColumn<>(label);c.setCellValueFactory(v->new SimpleStringProperty(fn.apply(v.getValue())));return c;}
    private void filter(){String q=search.getText().toLowerCase(Locale.ROOT);table.setItems(FXCollections.observableArrayList(rows.stream().filter(t->(t.description()+" "+t.category()+" "+t.type()).toLowerCase(Locale.ROOT).contains(q)).toList()));}
    private void refresh() throws Exception {
        YearMonth m=selectedMonth();rows=store.list(m);filter();long in=0,out=0;Map<String,Long> totals=new TreeMap<>();
        for(Transaction t:rows){if(t.type().equals("Income"))in+=t.cents();else{out+=t.cents();totals.merge(t.category(),t.cents(),Long::sum);}}
        long b=store.budget(m);income.setText(Transaction.money(in));expenses.setText(Transaction.money(out));balance.setText(Transaction.money(in-out));remaining.setText(b==0?"Set a budget":Transaction.money(b-out));
        budgetUsage.setText(b==0?"Set a monthly expense budget below.":String.format(Locale.US,"%.0f%% of %s budget used",100.0*out/b,Transaction.money(b)));
        progress.setStyle(out>b && b>0?"-fx-accent: #c13d3d;":"-fx-accent: #126d70;");
        remaining.setStyle(out>b && b>0?"-fx-text-fill: #c13d3d;":"");
        progress.setProgress(b==0?0:Math.min(1,(double)out/b));chart.setData(FXCollections.observableArrayList(totals.entrySet().stream().map(e->new PieChart.Data(e.getKey(),e.getValue()/100.0)).toList()));
        status.setText(rows.size()+" transactions • Summaries include the full selected month • Data saved locally");
    }
    @Override public void stop() throws Exception {if(store!=null)store.close();}
    public static void main(String[] args){launch(args);}
}
