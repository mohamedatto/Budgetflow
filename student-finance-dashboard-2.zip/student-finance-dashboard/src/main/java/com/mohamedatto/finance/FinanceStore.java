package com.mohamedatto.finance;

import java.sql.*;
import java.time.*;
import java.util.*;

/** Prepared statements keep user input separate from SQL. */
public final class FinanceStore implements AutoCloseable {
    private final Connection db;
    public FinanceStore(String url) throws SQLException {
        db = DriverManager.getConnection(url);
        try (Statement s = db.createStatement()) {
            s.execute("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY, date TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN ('Income','Expense')), cents INTEGER NOT NULL CHECK(cents > 0))");
            s.execute("CREATE INDEX IF NOT EXISTS idx_transaction_date ON transactions(date)");
            s.execute("CREATE TABLE IF NOT EXISTS budgets (month TEXT PRIMARY KEY, cents INTEGER NOT NULL CHECK(cents > 0))");
        }
    }
    public void add(Transaction t) throws SQLException {
        try (PreparedStatement s = db.prepareStatement("INSERT INTO transactions(date,description,category,type,cents) VALUES(?,?,?,?,?)")) {
            s.setString(1,t.date().toString()); s.setString(2,t.description().trim()); s.setString(3,t.category()); s.setString(4,t.type()); s.setLong(5,t.cents()); s.executeUpdate();
        }
    }
    public List<Transaction> list(YearMonth month) throws SQLException {
        List<Transaction> out = new ArrayList<>();
        try (PreparedStatement s = db.prepareStatement("SELECT * FROM transactions WHERE date >= ? AND date < ? ORDER BY date DESC,id DESC")) {
            s.setString(1,month.atDay(1).toString()); s.setString(2,month.plusMonths(1).atDay(1).toString());
            try (ResultSet r = s.executeQuery()) { while(r.next()) out.add(new Transaction(r.getLong("id"),LocalDate.parse(r.getString("date")),r.getString("description"),r.getString("category"),r.getString("type"),r.getLong("cents"))); }
        }
        return out;
    }
    public void delete(long id) throws SQLException {
        try(PreparedStatement s=db.prepareStatement("DELETE FROM transactions WHERE id=?")){s.setLong(1,id);s.executeUpdate();}
    }
    public void budget(YearMonth month,long cents) throws SQLException {
        if(cents <= 0) throw new IllegalArgumentException("Budget must be positive.");
        try(PreparedStatement s=db.prepareStatement("INSERT INTO budgets(month,cents) VALUES(?,?) ON CONFLICT(month) DO UPDATE SET cents=excluded.cents")){s.setString(1,month.toString());s.setLong(2,cents);s.executeUpdate();}
    }
    public long budget(YearMonth month) throws SQLException {
        try(PreparedStatement s=db.prepareStatement("SELECT cents FROM budgets WHERE month=?")){s.setString(1,month.toString());try(ResultSet r=s.executeQuery()){return r.next()?r.getLong(1):0;}}
    }
    public boolean seed(YearMonth month) throws SQLException {
        if (!list(month).isEmpty()) return false;
        boolean previous=db.getAutoCommit(); db.setAutoCommit(false);
        try {
            add(new Transaction(0,month.atDay(1),"Sample: campus job","Other","Income",120000));
            add(new Transaction(0,month.atDay(2),"Sample: rent","Housing","Expense",65000));
            add(new Transaction(0,month.atDay(3),"Sample: groceries","Food","Expense",6845));
            add(new Transaction(0,month.atDay(4),"Sample: bus pass","Transport","Expense",4500));
            add(new Transaction(0,month.atDay(5),"Sample: textbook","School","Expense",7200));
            budget(month,100000); db.commit(); return true;
        } catch(SQLException e){db.rollback();throw e;} finally{db.setAutoCommit(previous);}
    }
    public void close() throws SQLException {db.close();}
}
